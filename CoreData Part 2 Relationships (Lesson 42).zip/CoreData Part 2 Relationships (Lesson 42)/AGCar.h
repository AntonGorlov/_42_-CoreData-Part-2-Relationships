//
//  AGCar.h
//  CoreData Part 2 Relationships (Lesson 42)
//
//  Created by Anton Gorlov on 22.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AGObject.h"

@class AGStudent;

NS_ASSUME_NONNULL_BEGIN

@interface AGCar : AGObject

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "AGCar+CoreDataProperties.h"
