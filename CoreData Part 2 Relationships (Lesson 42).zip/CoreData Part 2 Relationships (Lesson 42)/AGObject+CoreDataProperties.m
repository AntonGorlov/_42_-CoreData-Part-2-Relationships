//
//  AGObject+CoreDataProperties.m
//  CoreData Part 2 Relationships (Lesson 42)
//
//  Created by Anton Gorlov on 22.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "AGObject+CoreDataProperties.h"

@implementation AGObject (CoreDataProperties)

- (BOOL) validateForDelete:(NSError * _Nullable __autoreleasing *)error {

    NSLog(@"%@ VALIDATION FOR DELETE", NSStringFromClass([ self class]));
    
    return YES;
}
@end
