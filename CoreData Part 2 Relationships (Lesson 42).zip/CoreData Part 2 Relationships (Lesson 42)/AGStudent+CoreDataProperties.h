//
//  AGStudent+CoreDataProperties.h
//  CoreData Part 2 Relationships (Lesson 42)
//
//  Created by Anton Gorlov on 22.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "AGStudent.h"

NS_ASSUME_NONNULL_BEGIN

@interface AGStudent (CoreDataProperties)

@property (nullable, nonatomic, retain) NSDate *dateOfBirht;
@property (nullable, nonatomic, retain) NSString *firstName;
@property (nullable, nonatomic, retain) NSString *lastName;
@property (nullable, nonatomic, retain) NSNumber *score;
@property (nullable, nonatomic, retain) AGCar *car;
@property (nullable, nonatomic, retain) NSSet<AGCourse *> *courses;
@property (nullable, nonatomic, retain) AGUniversity *university;

@end

@interface AGStudent (CoreDataGeneratedAccessors)

- (void)addCoursesObject:(AGCourse *)value;
- (void)removeCoursesObject:(AGCourse *)value;
- (void)addCourses:(NSSet<AGCourse *> *)values;
- (void)removeCourses:(NSSet<AGCourse *> *)values;

@end

NS_ASSUME_NONNULL_END
