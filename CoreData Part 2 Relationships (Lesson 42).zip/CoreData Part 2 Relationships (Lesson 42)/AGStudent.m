//
//  AGStudent.m
//  CoreData Part 2 Relationships (Lesson 42)
//
//  Created by Anton Gorlov on 22.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGStudent.h"
#import "AGCar.h"
#import "AGCourse.h"
#import "AGUniversity.h"

@implementation AGStudent

// Insert code here to add functionality to your managed object subclass

@end
