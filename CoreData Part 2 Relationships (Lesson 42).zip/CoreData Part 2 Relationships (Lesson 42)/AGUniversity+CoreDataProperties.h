//
//  AGUniversity+CoreDataProperties.h
//  CoreData Part 2 Relationships (Lesson 42)
//
//  Created by Anton Gorlov on 22.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "AGUniversity.h"

NS_ASSUME_NONNULL_BEGIN

@interface AGUniversity (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *name;
@property (nullable, nonatomic, retain) NSSet<AGCourse *> *course;
@property (nullable, nonatomic, retain) NSSet<AGStudent *> *students;

@end

@interface AGUniversity (CoreDataGeneratedAccessors)

- (void)addCourseObject:(AGCourse *)value;
- (void)removeCourseObject:(AGCourse *)value;
- (void)addCourse:(NSSet<AGCourse *> *)values;
- (void)removeCourse:(NSSet<AGCourse *> *)values;

- (void)addStudentsObject:(AGStudent *)value;
- (void)removeStudentsObject:(AGStudent *)value;
- (void)addStudents:(NSSet<AGStudent *> *)values;
- (void)removeStudents:(NSSet<AGStudent *> *)values;

@end

NS_ASSUME_NONNULL_END
