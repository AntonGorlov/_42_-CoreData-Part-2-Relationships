//
//  ViewController.h
//  CoreData Part 2 Relationships (Lesson 42)
//
//  Created by Anton Gorlov on 21.08.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

